package com.ivguard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IVGuardApplication {
    public static void main(String[] args) {
        SpringApplication.run(IVGuardApplication.class, args);
    }
}
