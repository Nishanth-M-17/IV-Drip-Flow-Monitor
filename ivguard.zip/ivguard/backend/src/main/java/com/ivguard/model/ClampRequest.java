package com.ivguard.model;

/**
 * Payload for POST /api/clamp
 * Sent by the frontend when the operator hits EMERGENCY CLAMP.
 */
public class ClampRequest {

    private String roomId;      // "201"
    private String patientId;   // "john-doe"
    private String action;      // "LOCK" | "UNLOCK"
    private String timestamp;   // ISO-8601 string from frontend

    /* ── Getters & Setters ── */
    public String getRoomId()            { return roomId; }
    public void   setRoomId(String v)    { this.roomId = v; }

    public String getPatientId()         { return patientId; }
    public void   setPatientId(String v) { this.patientId = v; }

    public String getAction()            { return action; }
    public void   setAction(String v)    { this.action = v; }

    public String getTimestamp()         { return timestamp; }
    public void   setTimestamp(String v) { this.timestamp = v; }
}
