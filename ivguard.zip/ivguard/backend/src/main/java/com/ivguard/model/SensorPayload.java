package com.ivguard.model;

/**
 * Payload sent by the ESP32-S3 via POST /api/sensor-data
 */
public class SensorPayload {

    private String roomId;         // e.g. "201"
    private String patientId;      // e.g. "john-doe"
    private double currentVolume;  // ml remaining
    private double totalVolume;    // ml total (e.g. 500.0)
    private double dpm;            // drops per minute
    private long   timestamp;      // epoch millis (optional)

    /* ── Getters & Setters ── */
    public String getRoomId()             { return roomId; }
    public void   setRoomId(String v)     { this.roomId = v; }

    public String getPatientId()          { return patientId; }
    public void   setPatientId(String v)  { this.patientId = v; }

    public double getCurrentVolume()      { return currentVolume; }
    public void   setCurrentVolume(double v) { this.currentVolume = v; }

    public double getTotalVolume()        { return totalVolume; }
    public void   setTotalVolume(double v){ this.totalVolume = v; }

    public double getDpm()                { return dpm; }
    public void   setDpm(double v)        { this.dpm = v; }

    public long   getTimestamp()          { return timestamp; }
    public void   setTimestamp(long v)    { this.timestamp = v; }

    /** Convenience: percentage remaining (0–100) */
    public double getVolumePct() {
        if (totalVolume <= 0) return 0;
        return (currentVolume / totalVolume) * 100.0;
    }
}
