package com.ivguard.websocket;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Central service for broadcasting messages to all connected frontends.
 *
 * Destination conventions:
 *   /topic/sensor          → live DPM + volume updates (all rooms)
 *   /topic/alerts          → critical / warning alerts
 *   /topic/clamp/{roomId}  → clamp acknowledgements
 */
@Service
public class WebSocketBroadcaster {

    private static final Logger log = LoggerFactory.getLogger(WebSocketBroadcaster.class);
    private final SimpMessagingTemplate template;

    public WebSocketBroadcaster(SimpMessagingTemplate template) {
        this.template = template;
    }

    /** Broadcast a live sensor update to the dashboard. */
    public void broadcastSensorUpdate(String roomId, double dpm, double volumePct) {
        Map<String, Object> msg = Map.of(
            "type",      "SENSOR_UPDATE",
            "roomId",    roomId,
            "dpm",       Math.round(dpm * 10.0) / 10.0,
            "volumePct", Math.round(volumePct * 10.0) / 10.0
        );
        log.debug("Broadcasting sensor update → Room {} | DPM={} | Vol={}%", roomId, dpm, volumePct);
        template.convertAndSend("/topic/sensor", msg);
    }

    /** Broadcast a critical or warning alert. */
    public void broadcastAlert(String roomId, String severity, String message) {
        Map<String, Object> msg = Map.of(
            "type",     "CRITICAL_ALERT",
            "roomId",   roomId,
            "severity", severity,      // "CRITICAL" | "WARNING" | "INFO"
            "message",  message
        );
        log.warn("Broadcasting alert → Room {} | {} | {}", roomId, severity, message);
        template.convertAndSend("/topic/alerts", msg);
    }

    /** Acknowledge a clamp command back to the frontend. */
    public void broadcastClampAck(String roomId, String status) {
        Map<String, Object> msg = Map.of(
            "type",   "CLAMP_ACK",
            "roomId", roomId,
            "status", status
        );
        log.info("Broadcasting clamp ACK → Room {} | Status={}", roomId, status);
        template.convertAndSend("/topic/clamp/" + roomId, msg);
    }
}
