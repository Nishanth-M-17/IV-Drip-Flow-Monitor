package com.ivguard.websocket;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.*;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Value("${ivguard.cors.allowed-origins}")
    private String[] allowedOrigins;

    /**
     * Register the /ws endpoint.
     * SockJS fallback is enabled so the browser can connect even if
     * native WebSocket is blocked (e.g. corporate proxies).
     */
    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws")
                .setAllowedOriginPatterns("*")   // tighten this in production
                .withSockJS();

        // Also accept raw WebSocket (no SockJS) — used by the frontend app.js
        registry.addEndpoint("/ws")
                .setAllowedOriginPatterns("*");
    }

    /**
     * /topic/** → broadcast (pub-sub)
     * /app/**   → messages routed to @MessageMapping methods
     */
    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        registry.enableSimpleBroker("/topic");
        registry.setApplicationDestinationPrefixes("/app");
    }
}
